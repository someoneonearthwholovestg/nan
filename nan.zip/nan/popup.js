const $ = id => document.getElementById(id);
async function loadSettings(){
  const data=await chrome.storage.local.get(["apiKey","model","usageByMonth","simpleMode"]);
  $("apiKey").value=data.apiKey||"";
  $("model").value=data.model||"gemini-3.8-flash";
  $("simpleMode").checked=data.simpleMode!==false;
  renderUsage(data.usageByMonth||{});
}
function monthKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;}
function renderUsage(all){const u=all[monthKey()]||{requests:0,totalTokens:0};$("requests").textContent=Number(u.requests||0).toLocaleString();$("tokens").textContent=Number(u.totalTokens||0).toLocaleString();}
$("save").addEventListener("click",async()=>{
  const apiKey=$("apiKey").value.trim();
  if(!apiKey){$("status").textContent="Paste your Gemini API key first.";return;}
  await chrome.storage.local.set({apiKey,model:$("model").value.trim()||"gemini-3.8-flash",simpleMode:$("simpleMode").checked});
  $("status").textContent="Settings saved on this Chrome profile.";
});
$("toggleKey").addEventListener("click",()=>{const i=$("apiKey");const show=i.type==="password";i.type=show?"text":"password";$("toggleKey").textContent=show?"Hide":"Show";});
$("refresh").addEventListener("click",loadSettings);
$("resetUsage").addEventListener("click",async()=>{const d=await chrome.storage.local.get(["usageByMonth"]);const all=d.usageByMonth||{};delete all[monthKey()];await chrome.storage.local.set({usageByMonth:all});renderUsage(all);});
loadSettings();
$("capture").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"ASK_AI_START_CAPTURE"},()=>window.close());});
