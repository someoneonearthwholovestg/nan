
const MENU_TEXT = "ask-ai-selected-text";
const MENU_SHOT = "ask-ai-capture-area";

const DEFAULT_MODEL = "gemini-3.5-flash";

const PARALLEL_MODELS = [
  "gemini-3.5-flash",
  "gemini-3.1-flash-lite"
];

// Built-in key
const BUILT_IN_KEY = "AIzaSyDvEhsN4qHk_hdgiJMKnmwbmRfKvIRWp2s";

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const SYSTEM_PROMPT =
  "You answer multiple-choice questions. Reply with ONLY the correct option letter, " +
  "such as A, B, C, or D. Never include the option text, explanation, punctuation, " +
  "or any additional words. If multiple options are correct, reply with their letters " +
  "separated by commas (example: A, C). If options have no letters, use their " +
  "corresponding position (1, 2, 3, etc.). If the input is not a multiple-choice " +
  "question, give the shortest possible direct answer.";


/* ---------- Menus and shortcuts ---------- */

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_TEXT,
      title: "Ask AI (answer only)",
      contexts: ["selection"]
    });

    chrome.contextMenus.create({
      id: MENU_SHOT,
      title: "Ask AI: screenshot area",
      contexts: ["page", "selection", "image", "frame"]
    });
  });
}

chrome.runtime.onInstalled.addListener(createMenus);

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) return;

  if (info.menuItemId === MENU_TEXT) {
    const text = (info.selectionText || "").trim();

    if (text) {
      sendToTab(tab.id, {
        type: "ASK_AI_SHOW_TEXT",
        text
      });
    }
  } else if (info.menuItemId === MENU_SHOT) {
    sendToTab(tab.id, {
      type: "ASK_AI_SELECT_AREA"
    });
  }
});

chrome.commands.onCommand.addListener(async command => {
  if (command !== "capture-area") return;

  const [tab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });

  if (tab?.id) {
    sendToTab(tab.id, {
      type: "ASK_AI_SELECT_AREA"
    });
  }
});


/* ---------- Send messages to tab ---------- */

async function sendToTab(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message, {
      frameId: 0
    });
  } catch {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });

      await chrome.tabs.sendMessage(tabId, message, {
        frameId: 0
      });
    } catch (e) {
      console.debug(
        "Ask AI cannot run on this page:",
        e?.message
      );

      chrome.action.setBadgeText({
        text: "!",
        tabId
      });

      setTimeout(() => {
        chrome.action.setBadgeText({
          text: "",
          tabId
        });
      }, 1000);
    }
  }
}


/* ---------- Messages from page / popup ---------- */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message?.type === "ASK_AI_TEXT") {
    run(() => askText(message.text)).then(sendResponse);
    return true;
  }

  if (message?.type === "ASK_AI_CAPTURE") {
    run(() => askScreenshot(message, sender)).then(sendResponse);
    return true;
  }

  if (message?.type === "ASK_AI_START_CAPTURE") {
    chrome.tabs.query({
      active: true,
      lastFocusedWindow: true
    }).then(([tab]) => {
      if (tab?.id) {
        sendToTab(tab.id, {
          type: "ASK_AI_SELECT_AREA"
        });
      }
    });

    sendResponse({ ok: true });
  }
});


/* ---------- Error handler ---------- */

async function run(fn) {
  try {
    return {
      ok: true,
      ...(await fn())
    };
  } catch (e) {
    return {
      ok: false,
      error: e?.message || "Something went wrong."
    };
  }
}


/* ---------- Request builders ---------- */

function askText(text) {
  const clean = String(text || "").slice(0, 30000);

  return callGemini([
    {
      text: `Question:\n${clean}`
    }
  ]);
}


async function askScreenshot(message, sender) {
  const { rect, vw } = message;

  if (!rect || !vw) {
    throw new Error("No area selected.");
  }

  const dataUrl = await chrome.tabs.captureVisibleTab(
    sender.tab.windowId,
    { format: "png" }
  );

  const bitmap = await createImageBitmap(
    await (await fetch(dataUrl)).blob()
  );

  const scale = bitmap.width / vw;

  const sx = Math.max(0, Math.round(rect.x * scale));
  const sy = Math.max(0, Math.round(rect.y * scale));

  const sw = Math.min(
    bitmap.width - sx,
    Math.round(rect.w * scale)
  );

  const sh = Math.min(
    bitmap.height - sy,
    Math.round(rect.h * scale)
  );

  if (sw < 8 || sh < 8) {
    throw new Error("Selected area is too small.");
  }

  const down = Math.min(
    1,
    1600 / Math.max(sw, sh)
  );

  const ow = Math.round(sw * down);
  const oh = Math.round(sh * down);

  const canvas = new OffscreenCanvas(ow, oh);

  canvas.getContext("2d").drawImage(
    bitmap,
    sx, sy, sw, sh,
    0, 0, ow, oh
  );

  const blob = await canvas.convertToBlob({
    type: "image/png"
  });

  const data = toBase64(
    new Uint8Array(await blob.arrayBuffer())
  );

  return callGemini([
    {
      inlineData: {
        mimeType: "image/png",
        data
      }
    },
    {
      text: "Answer the multiple-choice question shown in this image."
    }
  ]);
}


function toBase64(bytes) {
  let bin = "";

  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode(
      ...bytes.subarray(i, i + 0x8000)
    );
  }

  return btoa(bin);
}


/* ---------- Gemini parallel execution ---------- */

async function callGemini(parts) {

  const settings = await chrome.storage.local.get([
    "apiKey",
    "simpleMode"
  ]);

  const apiKey = (
    settings.apiKey || BUILT_IN_KEY || ""
  ).trim();

  if (!apiKey) {
    throw new Error(
      "No API key set. Add one in the Ask AI toolbar settings."
    );
  }

  const simple = settings.simpleMode !== false;

  // Both models start at the same time.
  const results = await Promise.allSettled(
    PARALLEL_MODELS.map(model =>
      requestModel(model, parts, apiKey, simple)
    )
  );

  const answers = results.map((result, index) => ({
    model: PARALLEL_MODELS[index],

    success: result.status === "fulfilled",

    answer:
      result.status === "fulfilled"
        ? result.value.answer
        : null,

    error:
      result.status === "rejected"
        ? result.reason?.message || "Unknown error"
        : null
  }));

  // Aggregate token usage once to avoid concurrent storage overwrites.
  const successful = results
    .filter(result => result.status === "fulfilled")
    .map(result => result.value.usage);

  if (successful.length) {
    const inputTokens = successful.reduce(
      (sum, usage) => sum + usage.input,
      0
    );

    const outputTokens = successful.reduce(
      (sum, usage) => sum + usage.output,
      0
    );

    await recordUsage(inputTokens, outputTokens);
  }

  // Both models failed.
  if (!successful.length) {
    throw new Error(
      answers.map(item =>
        `${item.model}: ${item.error}`
      ).join("\n")
    );
  }

  // Create a combined answer for compatibility with
  // interfaces that previously displayed a single answer.
  const combinedAnswer = answers.map(item => {

    if (item.success) {
      return `${item.model}:\n${item.answer}`;
    }

    return `${item.model}:\nError: ${item.error}`;

  }).join("\n\n");

  return {
    answer: combinedAnswer,
    model: "parallel",
    answers
  };
}


/* ---------- Individual model request ---------- */

async function requestModel(model, parts, apiKey, simple) {

  let useThinkingOff = simple;
  let lastError = "Unknown error";

  // Each model gets its own retry system.
  for (let attempt = 0; attempt < 2; attempt++) {

    const generationConfig = {
      temperature: 0,
      maxOutputTokens: simple ? 300 : 4096
    };

    if (useThinkingOff) {
      generationConfig.thinkingConfig = {
        thinkingBudget: 0
      };
    }

    const controller = new AbortController();

    const timer = setTimeout(
      () => controller.abort(),
      30000
    );

    let response;

    try {

      response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
        {
          method: "POST",
          signal: controller.signal,

          headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": apiKey
          },

          body: JSON.stringify({
            systemInstruction: {
              parts: [
                { text: SYSTEM_PROMPT }
              ]
            },

            contents: [
              {
                role: "user",
                parts
              }
            ],

            generationConfig
          })
        }
      );

    } catch (e) {

      if (e?.name === "AbortError") {
        throw new Error(
          `Timed out after 30 seconds (${model}).`
        );
      }

      throw new Error(
        `Could not reach Gemini (${model}). Check your internet connection.`
      );

    } finally {
      clearTimeout(timer);
    }

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {

      const detail =
        data?.error?.message || `HTTP ${response.status}`;

      // Retry without thinking configuration.
      if (
        response.status === 400 &&
        useThinkingOff &&
        /thinking/i.test(detail)
      ) {
        useThinkingOff = false;
        attempt--;
        continue;
      }

      if (response.status === 404) {
        throw new Error(
          `Model not found: ${model}.`
        );
      }

      // Retry temporary server errors once.
      if (
        response.status === 500 ||
        response.status === 503 ||
        response.status === 504
      ) {
        lastError = `Gemini is busy (${model}).`;

        if (attempt < 1) {
          await sleep(600);
          continue;
        }

        break;
      }

      if (response.status === 429) {
        throw new Error(
          `Rate limit reached for ${model}: ${detail}`
        );
      }

      if (
        response.status === 400 &&
        /API key/i.test(detail)
      ) {
        throw new Error("Invalid API key.");
      }

      throw new Error(
        `${model}: ${detail}`
      );
    }

    const candidate = data?.candidates?.[0];

    const answer = (
      candidate?.content?.parts || []
    )
      .filter(part => !part.thought)
      .map(part => part.text || "")
      .join("\n")
      .trim();

    if (!answer) {

      if (data?.promptFeedback?.blockReason) {
        throw new Error(
          `Blocked by Gemini: ${data.promptFeedback.blockReason}`
        );
      }

      if (candidate?.finishReason === "MAX_TOKENS") {
        throw new Error(
          `${model} ran out of output tokens.`
        );
      }

      throw new Error(
        `${model} returned an empty answer.`
      );
    }

    const usage = data?.usageMetadata || {};

    return {
      answer,

      usage: {
        input: Number(usage.promptTokenCount || 0),
        output: Number(usage.candidatesTokenCount || 0)
      }
    };
  }

  throw new Error(lastError);
}


/* ---------- Usage tracking ---------- */

async function recordUsage(inputTokens, outputTokens) {

  const now = new Date();

  const month =
    `${now.getFullYear()}-${String(
      now.getMonth() + 1
    ).padStart(2, "0")}`;

  const stored = await chrome.storage.local.get([
    "usageByMonth"
  ]);

  const all = stored.usageByMonth || {};

  const cur = all[month] || {
    requests: 0,
    inputTokens: 0,
    outputTokens: 0,
    totalTokens: 0
  };

  // One user question counts as one request,
  // even though two models were called.
  cur.requests++;

  cur.inputTokens += inputTokens;
  cur.outputTokens += outputTokens;

  cur.totalTokens += inputTokens + outputTokens;

  cur.lastUsed = now.toISOString();

  all[month] = cur;

  await chrome.storage.local.set({
    usageByMonth: all
  });
}
