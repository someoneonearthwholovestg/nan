(() => {
  if (window.__askAiAnswerOnly) return;
  window.__askAiAnswerOnly = true;
  if (window !== window.top) return;           // only the top frame draws UI

  const AUTO_CLOSE_MS = 12000;
  let host, shadow, box, txt, hideTimer, reqId = 0, selecting = false;

  /* ---------- small answer popup ---------- */
  function ensureToast() {
    if (host?.isConnected) return;
    host = document.createElement("div");
    host.style.cssText = "all:initial;position:fixed;z-index:2147483647;right:18px;bottom:18px;";
    shadow = host.attachShadow({mode: "closed"});
    const style = document.createElement("style");
    style.textContent = `
      *{box-sizing:border-box}
      .toast{display:flex;align-items:center;gap:10px;min-width:110px;max-width:min(320px,calc(100vw - 36px));padding:11px 11px 11px 16px;
        color:#f5f6fa;background:linear-gradient(145deg,#1d222d,#141820);border:1px solid #3b4352;border-radius:22px;
        box-shadow:0 14px 40px #0009;font:600 16px/1.35 Inter,system-ui,sans-serif;animation:pop .16s ease-out}
      @keyframes pop{from{opacity:0;transform:translateY(8px) scale(.97)}to{opacity:1;transform:none}}
      .txt{flex:1;white-space:pre-wrap;overflow-wrap:anywhere;max-height:40vh;overflow:auto}
      .txt.answer{color:#a7f3d0}
      .txt.err{color:#fecdd3;font:500 12px/1.4 Inter,system-ui,sans-serif}
      .toast.loading{min-width:0;padding:10px 12px}
      .toast.loading{padding-right:6px}
      .txt.loading{display:flex;align-items:center;justify-content:center;min-width:10px}
      .dot{width:9px;height:9px;border-radius:50%;background:#a7f3d0;animation:pulse 1s ease-in-out infinite}
      @keyframes pulse{0%,100%{opacity:.25;transform:scale(.7)}50%{opacity:1;transform:scale(1)}}
      .x{flex:0 0 24px;width:24px;height:24px;border:0;border-radius:50%;background:#303846;color:#dce3ee;font:16px/1 system-ui;cursor:pointer}
      .x:hover{background:#3d4757}`;
    box = document.createElement("div");
    box.className = "toast";
    txt = document.createElement("div");
    txt.className = "txt";
    const x = document.createElement("button");
    x.className = "x"; x.setAttribute("aria-label", "Close"); x.textContent = "×";
    x.addEventListener("click", closeToast);
    box.append(txt, x);
    box.addEventListener("mouseenter", () => clearTimeout(hideTimer));
    box.addEventListener("mouseleave", () => { if (txt.classList.contains("answer") || txt.classList.contains("err")) scheduleClose(); });
    shadow.append(style, box);
    document.documentElement.appendChild(host);
  }

  function show(kind, text) {
    ensureToast();
    host.style.display = "block";
    clearTimeout(hideTimer);
    txt.className = "txt " + kind;
    box.className = "toast " + (kind === "loading" ? "loading" : "");
    txt.replaceChildren();
    if (kind === "loading") {
      const dot = document.createElement("span"); dot.className = "dot";
      txt.append(dot);
    } else {
      txt.textContent = text;
      scheduleClose();
    }
  }
  function scheduleClose() { clearTimeout(hideTimer); hideTimer = setTimeout(closeToast, AUTO_CLOSE_MS); }
  function closeToast() { clearTimeout(hideTimer); reqId++; if (host) host.style.display = "none"; }

  async function ask(message) {
    const id = ++reqId;
    show("loading");
    let reply;
    try {
      reply = await Promise.race([
        chrome.runtime.sendMessage(message),
        new Promise((_, rej) => setTimeout(() => rej(new Error("No response. Reload the extension and refresh this page.")), 60000))
      ]);
    }
    catch (e) {
      reply = {ok: false, error: /context invalidated/i.test(e?.message || "")
        ? "Extension was reloaded. Refresh this page and try again." : (e?.message || "Something went wrong.")};
    }
    if (id !== reqId) return;                    // closed or replaced meanwhile
    if (reply?.ok) show("answer", reply.answer);
    else show("err", reply?.error || "Something went wrong.");
  }

  /* ---------- screenshot area selector ---------- */
  function startSelect() {
    if (selecting) return;
    selecting = true;
    closeToast();
    const h = document.createElement("div");
    h.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;cursor:crosshair;";
    const sh = h.attachShadow({mode: "closed"});
    sh.innerHTML = `<style>
      .dim{position:absolute;inset:0;background:rgba(0,0,0,.35)}
      .box{position:absolute;display:none;border:2px solid #a7f3d0;border-radius:6px;box-shadow:0 0 0 9999px rgba(0,0,0,.45)}
      .tip{position:absolute;top:14px;left:50%;transform:translateX(-50%);padding:8px 14px;border-radius:999px;background:#141820;color:#e8edf5;
        border:1px solid #3b4352;font:12px/1 Inter,system-ui,sans-serif}
    </style><div class="dim"></div><div class="box"></div><div class="tip">Drag around the question · Esc to cancel</div>`;
    const dim = sh.querySelector(".dim"), box = sh.querySelector(".box");
    document.documentElement.appendChild(h);

    let sx = 0, sy = 0, drawing = false, r = null;
    const cleanup = () => { selecting = false; window.removeEventListener("keydown", onKey, true); h.remove(); };
    const onKey = e => { if (e.key === "Escape") { e.preventDefault(); cleanup(); } };
    window.addEventListener("keydown", onKey, true);

    h.addEventListener("pointerdown", e => {
      e.preventDefault(); drawing = true; sx = e.clientX; sy = e.clientY;
      h.setPointerCapture(e.pointerId);
      dim.style.display = "none"; box.style.display = "block";
    });
    h.addEventListener("pointermove", e => {
      if (!drawing) return;
      const x = Math.min(sx, e.clientX), y = Math.min(sy, e.clientY);
      r = {x, y, w: Math.abs(e.clientX - sx), h: Math.abs(e.clientY - sy)};
      Object.assign(box.style, {left: x + "px", top: y + "px", width: r.w + "px", height: r.h + "px"});
    });
    h.addEventListener("pointerup", async () => {
      if (!drawing) return;
      drawing = false;
      const rect = r; cleanup();
      if (!rect || rect.w < 12 || rect.h < 12) return;
      // let the page repaint without the overlay before the screenshot is taken
      await new Promise(res => requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(res, 80))));
      ask({type: "ASK_AI_CAPTURE", rect, vw: window.innerWidth, vh: window.innerHeight});
    });
  }

  /* ---------- messages from the background ---------- */
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "ASK_AI_SHOW_TEXT") ask({type: "ASK_AI_TEXT", text: String(message.text || "")});
    else if (message?.type === "ASK_AI_SELECT_AREA") startSelect();
    else return;
    sendResponse({ok: true});
  });
})();
