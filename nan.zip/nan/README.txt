ASK AI — GEMINI, ANSWER-ONLY EDITION — VERSION 0.4.0

INSTALL
1. Extract this ZIP into a normal folder.
2. Open chrome://extensions and turn on Developer mode.
3. REMOVE the old Ask AI version (otherwise you get duplicate right-click items).
4. Click Load unpacked and choose the ask-ai-extension-stage3 folder.
5. The API key is already built in (see BUILT_IN_KEY in background.js). Nothing to paste.
   To use another key, paste it in the toolbar settings and save; that one wins.
6. Refresh any tab that was already open.

HOW TO USE
- Text: select the question, right-click -> "Ask AI (answer only)".
- Screenshot: press Alt+Shift+A (or toolbar icon -> "Screenshot an area", or
  right-click -> "Ask AI: screenshot area"), then drag a box around the question
  and its options. Esc cancels.
- A small popup in the bottom-right shows only the answer, e.g. "B) 4.5 V".
  It closes by itself after 12 seconds (hover to keep it), or press x.
- Change the shortcut at chrome://extensions/shortcuts.

WHAT CHANGED IN 0.4.0
- "High demand" (503) errors: now retried automatically, then falls through to
  backup models (gemini-flash-latest, gemini-2.5-flash, gemini-2.5-flash-lite).
- Simple mode (toolbar settings, ON by default): no deep thinking, short output, fastest answers.
- Popup shows only a small pulsing dot while loading, then just the answer.

WHAT CHANGED FROM 0.2.1
- Popup shows only the answer (no question, no buttons, no explanation).
- Screenshot-area -> Gemini vision.
- Works on tabs that were open before install (content script is injected on demand).
- Model is a free-text field; if the model is not found it falls back to
  gemini-flash-latest, then gemini-2.5-flash.
- Fixed empty answers when the model spent its token budget thinking.
- Errors (bad key, rate limit, model not found) show in the small popup.

NOTES
- Chrome blocks extensions on chrome:// pages and the Chrome Web Store.
- The key is written in plain text inside background.js. Do not share this folder or zip.
- Selected text and screenshots are sent to Google when you use Ask AI.
- AI answers can be wrong; double-check anything important.
