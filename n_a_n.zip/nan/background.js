const MENU_TEXT = "ask-ai-selected-text";
const MENU_SHOT = "ask-ai-capture-area";
const DEFAULT_MODEL = "gemini-3.5-flash";
// Built-in key: used automatically unless you save a different one in the toolbar settings.
const BUILT_IN_KEY = "AQ.Ab8RN6J5OZX2sBJ3rhN9N3AjDICAKootxnALXSlcK-PvN1io_A";
// Tried automatically if the chosen model is not found for your key/region.
const FALLBACK_MODELS = ["gemini-3.5-flash", "gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash", "gemini-2.5-flash-lite"];
const sleep = ms => new Promise(r => setTimeout(r, ms));


const SYSTEM_PROMPT =
  "You answer multiple-choice questions. Reply with ONLY the correct option letter, " +
  "such as A, B, C, or D. Never include the option text, explanation, punctuation, " +
  "or any additional words. If multiple options are correct, reply with their letters " +
  "separated by commas (example: A, C). If options have no letters, use their " +
  "corresponding position (1, 2, 3, etc.). If the input is not a multiple-choice " +
  "question, give the shortest possible direct answer.";


/* ---------- menus, shortcut ---------- */
function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({id: MENU_TEXT, title: "Ask AI (answer only)", contexts: ["selection"]});
    chrome.contextMenus.create({id: MENU_SHOT, title: "Ask AI: screenshot area", contexts: ["page", "selection", "image", "frame"]});
  });
}
chrome.runtime.onInstalled.addListener(createMenus);

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) return;
  if (info.menuItemId === MENU_TEXT) {
    const text = (info.selectionText || "").trim();
    if (text) sendToTab(tab.id, {type: "ASK_AI_SHOW_TEXT", text});
  } else if (info.menuItemId === MENU_SHOT) {
    sendToTab(tab.id, {type: "ASK_AI_SELECT_AREA"});
  }
});

chrome.commands.onCommand.addListener(async command => {
  if (command !== "capture-area") return;
  const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
  if (tab?.id) sendToTab(tab.id, {type: "ASK_AI_SELECT_AREA"});
});

// Sends a message to the page's top frame. If the page was opened before the
// extension was loaded/reloaded, inject the content script first.
async function sendToTab(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message, {frameId: 0});
  } catch {
    try {
      await chrome.scripting.executeScript({target: {tabId}, files: ["content.js"]});
      await chrome.tabs.sendMessage(tabId, message, {frameId: 0});
    } catch (e) {
      console.debug("Ask AI cannot run on this page:", e?.message);
      chrome.action.setBadgeText({text: "!", tabId});
      setTimeout(() => chrome.action.setBadgeText({text: "", tabId}), 1000);
    }
  }
}

/* ---------- messages from page / popup ---------- */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "ASK_AI_TEXT") {
    run(() => askText(message.text)).then(sendResponse);
    return true;
  }
  if (message?.type === "ASK_AI_CAPTURE") {
    run(() => askScreenshot(message, sender)).then(sendResponse);
    return true;
  }
  if (message?.type === "ASK_AI_START_CAPTURE") {   // from the toolbar popup button
    chrome.tabs.query({active: true, lastFocusedWindow: true}).then(([tab]) => {
      if (tab?.id) sendToTab(tab.id, {type: "ASK_AI_SELECT_AREA"});
    });
    sendResponse({ok: true});
  }
});

async function run(fn) {
  try { return {ok: true, ...(await fn())}; }
  catch (e) { return {ok: false, error: e?.message || "Something went wrong."}; }
}

/* ---------- request builders ---------- */
function askText(text) {
  const clean = String(text || "").slice(0, 30000);
  return callGemini([{text: `Question:\n${clean}`}]);
}

async function askScreenshot(message, sender) {
  const {rect, vw} = message;
  if (!rect || !vw) throw new Error("No area selected.");
  const dataUrl = await chrome.tabs.captureVisibleTab(sender.tab.windowId, {format: "png"});
  const bitmap = await createImageBitmap(await (await fetch(dataUrl)).blob());

  const scale = bitmap.width / vw;                       // handles DPR and browser zoom
  const sx = Math.max(0, Math.round(rect.x * scale));
  const sy = Math.max(0, Math.round(rect.y * scale));
  const sw = Math.min(bitmap.width - sx, Math.round(rect.w * scale));
  const sh = Math.min(bitmap.height - sy, Math.round(rect.h * scale));
  if (sw < 8 || sh < 8) throw new Error("Selected area is too small.");

  const down = Math.min(1, 1600 / Math.max(sw, sh));     // keep the upload small
  const ow = Math.round(sw * down), oh = Math.round(sh * down);
  const canvas = new OffscreenCanvas(ow, oh);
  canvas.getContext("2d").drawImage(bitmap, sx, sy, sw, sh, 0, 0, ow, oh);
  const blob = await canvas.convertToBlob({type: "image/png"});
  const data = toBase64(new Uint8Array(await blob.arrayBuffer()));

  return callGemini([
    {inlineData: {mimeType: "image/png", data}},
    {text: "Answer the multiple-choice question shown in this image."}
  ]);
}

function toBase64(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

/* ---------- Gemini ---------- */
async function callGemini(parts) {
  const settings = await chrome.storage.local.get(["apiKey", "model", "simpleMode"]);
  const apiKey = (settings.apiKey || BUILT_IN_KEY || "").trim();
  if (!apiKey) throw new Error("No API key set. Add one in the Ask AI toolbar settings.");
  const simple = settings.simpleMode !== false;          // Simple mode is ON by default
  const chosen = (settings.model || DEFAULT_MODEL).trim();
  const models = [chosen, ...FALLBACK_MODELS.filter(m => m !== chosen)];

  let lastError = "Unknown error";
  for (const model of models) {
    // Simple mode: no thinking, short output -> fastest possible answer.
    let useThinkingOff = simple;
    // Up to 2 tries per model when Google says "high demand" (503/500/504).
    for (let attempt = 0; attempt < 2; attempt++) {
      const generationConfig = {temperature: 0, maxOutputTokens: simple ? 300 : 4096};
      if (useThinkingOff) generationConfig.thinkingConfig = {thinkingBudget: 0};

      let response;
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 30000);   // never hang more than 15s per request
      try {
        response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
            method: "POST", signal: ctrl.signal,
            headers: {"Content-Type": "application/json", "x-goog-api-key": apiKey},
            body: JSON.stringify({
              systemInstruction: {parts: [{text: SYSTEM_PROMPT}]},
              contents: [{role: "user", parts}],
              generationConfig
            })
          });
      } catch (e) {
        clearTimeout(timer);
        if (e?.name === "AbortError") { lastError = `Timed out (${model}). Trying another model…`; break; }
        throw new Error("Could not reach Gemini. Check your internet connection.");
      }
      clearTimeout(timer);

      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail = data?.error?.message || `HTTP ${response.status}`;
        // model doesn't support turning thinking off -> retry same model without it
        if (response.status === 400 && useThinkingOff && /thinking/i.test(detail)) { useThinkingOff = false; attempt--; continue; }
        if (response.status === 404) { lastError = `Model "${model}" not found.`; break; }           // next model
        if (response.status === 503 || response.status === 500 || response.status === 504) {
          lastError = `Gemini is busy (${model}). Try again in a moment.`;
          if (attempt < 1) { await sleep(600); continue; }                          // retry
          break;                                                                                     // next model
        }
        if (response.status === 429) { lastError = "Gemini rate limit reached. Wait a bit and try again."; break; }
        if (response.status === 400 && /API key/i.test(detail)) throw new Error("Invalid API key. Check it in the settings.");
        throw new Error(`Gemini error: ${detail}`);
      }

      const candidate = data?.candidates?.[0];
      const answer = (candidate?.content?.parts || [])
        .filter(p => !p.thought).map(p => p.text || "").join("\n").replace(/\*\*/g, "").trim();
      if (!answer) {
        if (data?.promptFeedback?.blockReason) throw new Error(`Blocked by Gemini: ${data.promptFeedback.blockReason}`);
        if (candidate?.finishReason === "MAX_TOKENS") { lastError = "The model ran out of tokens. Try again."; break; }
        lastError = "Gemini returned an empty answer. Try again."; break;
      }

      const usage = data?.usageMetadata || {};
      await recordUsage(Number(usage.promptTokenCount || 0), Number(usage.candidatesTokenCount || 0));
      return {answer, model};
    }
  }
  throw new Error(lastError);
}

async function recordUsage(inputTokens, outputTokens) {
  const now = new Date();
  const month = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const stored = await chrome.storage.local.get(["usageByMonth"]);
  const all = stored.usageByMonth || {};
  const cur = all[month] || {requests: 0, inputTokens: 0, outputTokens: 0, totalTokens: 0};
  cur.requests++;
  cur.inputTokens += inputTokens;
  cur.outputTokens += outputTokens;
  cur.totalTokens += inputTokens + outputTokens;
  cur.lastUsed = now.toISOString();
  all[month] = cur;
  await chrome.storage.local.set({usageByMonth: all});
}
